<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="author" content="Fares Medhat">
  <meta name="generator" content="VScode">
  <meta name="copyright" content="Fares Medhat @2025">
  <title>Contact Us - Metro</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css"
    integrity="sha512-DxV+EoADOkOygM4IR9yXP8Sb2qwgidEmeqAEmDKIOfPRQZOWbXCzLC6vjbZyy0vPisbH2SyW27+ddLVCN+OMzQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

  <nav class="navbar navbar-expand-lg bg-body border-bottom border-secondary-subtle" id="navbar">
    <div class="container">
      <div class="collapse navbar-collapse nav-font" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <img src="images/english.png"> English
            </a>

            <ul class="dropdown-menu">

              <li><a href="#" class="dropdown-item"><img src="images/espanol.png"> Español</a></li>
              <li><a href="#" class="dropdown-item"><img src="images/francais.png"> Français</a></li>
              <li><a href="#" class="dropdown-item"><img src="images/portugues.png"> Português</a></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              USD
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">EUR</a></li>
              <li><a class="dropdown-item" href="#">BRL</a></li>
            </ul>
          </li>
          <div class="border-start border-secondary-subtle d-flex" style="height: 25px; margin: 0 1rem;"></div>
          <li class="nav-item"><a class="nav-link active" href="#">Track order</a></li>
          <li class="nav-item"><a class="nav-link active" href="contact.html">Contact</a></li>
          <li class="nav-item"><a class="nav-link active" href="#">FAQs</a></li>
        </ul>
        <ul class="navbar-nav  mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link active" href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
          <li class="nav-item"><a class="nav-link active" href="#"><i class="fa-brands fa-tiktok"></i></a></li>
          <li class="nav-item"><a class="nav-link active" href="#"><i class="fa-brands fa-youtube"></i></a></li>
          <li class="nav-item"><a class="nav-link active" href="#"><i class="fa-brands fa-instagram"></i></a></li>
          <li class="nav-item"><a class="nav-link active" href="#"><i class="fa-brands fa-x-twitter"></i></a></li>
          <div class="border-start border-secondary-subtle d-flex" style="height: 25px; margin: 0 1rem;"></div>
          <li class="nav-item"><a class="nav-link active" href="#">Contact us 24/7 <b>(+92) 3942 7879</b></a></li>
        </ul>

      </div>
    </div>
  </nav>
  <nav id="arrowtop" class="sticky-top">
    <div class="container-fluid ps-4 pe-4 bg-body">
      <div class="row justify-content-between">
        <div class="col-2 mt-4">
          <a href="index.html"><img src="images/logo-furniture.png" class="w-100"></a>
        </div>
        <div class="col-6 gy-4  border border-light border-3 rounded-2 bg-body-tertiary d-flex align-items-center">
          <div class="input-group ">
            <select class="form-select border-0 bg-body-tertiary " aria-label="Select the category">
              <option selected>All categories</option>
              <option value="1">Accessories</option>
              <option value="2">Electronics</option>
              <option value="3">Skincare</option>
              <option value="4">Applications</option>
              <option value="5">Electric Devices</option>
              <option value="6">Labtops</option>
              <option value="7">Camera</option>
              <option value="8">Body care</option>
              <option value="9">wire</option>
              <option value="10">Skincare</option>
              <option value="11">ipads</option>
              <option value="12">Furniture</option>
              <option value="13">Clothes</option>
              <option value="14">Cars</option>
              <option value="15">Bags</option>
            </select>
            <div class="border-start border-secondary-subtle d-flex" style="height: 25px; margin: 0 2rem;"></div>
            <input type="text" name="search-products" placeholder="Search for products"
              class="border-0 bg-transparent w-50">
            <button type="button" class="btn border btn-dark rounded-2"><a href="#"><i
                  class="fa-solid fa-magnifying-glass text-white"></i></a></button>
          </div>
        </div>
        <div class="col-3  gy-4">
          <ul class="d-flex  align-items-center icon-hover pt-3  ">
            <li class="pe-4 ps-5">
<a href="login.php" class="text-decoration-none">
<i class="fa-regular fa-user"></i> Account
</a>
</li>
            <div class="pe-4">
              <li class="position-relative"><a href="#"><i class="fa-regular fa-heart"></i></a>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-color">0
                  <span class="visually-hidden">Wishlist</span>
                </span>
              </li>
            </div>
            <li class="position-relative "><a href="#"><i class="fa-solid fa-cart-shopping"></i></a>
              <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-color">0
                <span class="visually-hidden">Shopping box</span>
              </span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </nav>

  <div class="container-fluid ">
    <div class="row d-flex justify-content-between align-items-center mt-5  border">
      <div class="col-3  position-relative ps-3">
        <div class="accordion">
          <h2 class="accordion-header">
            <button class="accordion-button bg-body collapsed" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
              <i class="fa-solid fa-bars"></i>SHOP BY CATEGORIES</button>
          </h2>
          <div id="collapseOne" class=" accordion-panel-content accordion-collapse collapse"
            aria-labelledby="headingOne">
            <div class="accordion-item fs-6">
              <div class="border-bottom px-4 py-3"><span><i class="fa-solid fa-couch"></i></span><a href="#"> Living
                  Room</a></div>
              <div class="border-bottom px-4 py-3"><span><i class="fa-solid fa-bed"></i></span><a href="#"> Bedroom</a>
              </div>
              <div class="border-bottom px-4 py-3"><span><i class="fa-solid fa-utensils"></i></span><a href="">Dining
                  Room</a></div>
              <div class="border-bottom px-4 py-3"><span><i class="fa-solid fa-bath"></i></span><a href="#">
                  Bathroom</a></div>
              <div class="border-bottom px-4 py-3">
                <sapn><i class="fa-solid fa-utensils"></i></sapn><a href="#"> Kitchen room</a>
              </div>
              <div class="border-bottom px-4 py-3"><span><i class="fa-solid fa-house-laptop"></i></span><a href="#">
                  Home Office</a></div>
              <div class="border-bottom px-4 py-3"><span><i class="fa-solid fa-wand-magic-sparkles"></i></span><a
                  href="">Home Decoration</a></div>
              <div class="border-bottom px-4 py-3"><span><i class="fa-solid fa-person-hiking"></i></span><a
                  href="">Outdoor</a></div>
              <div class="border-bottom px-4 py-3"><span><i class="fa-solid fa-percent"></i></span><a href="">Sale
                  Off</a></div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-6 pt-3">
        <ul class="d-flex align-items-center justify-content-between">
          <li class="dropdown pe-4"> <a class="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">Home</a></li>
          <li class="dropdown pe-4"> <a class="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">Shop</a></li>
          <li class="dropdown pe-4"> <a class="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">Product</a></li>
          <li class="dropdown pe-4"> <a class="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">Pages</a></li>
          <li class="pe-4"><a href="#" class="text-decoration-none">Blog</a></li>
          <li><a href="#" class="text-decoration-none ">About us</a></li>
        </ul>
      </div>
      <div class="col-2">
        <div class="dropdown"><a class="dropdown-toggle pe-3" href="#" role="button" data-bs-toggle="dropdown"
            aria-expanded="false">Recently viewed</a></div>
      </div>
    </div>
  </div>
  </div>
  </div>

  <div class="row text-center mt-5 pt-5 d-flex justify-content-between align-items-center">
    <h1>Contact Us</h1>
    <small>34 Main Street, Los Angeles 9021 United States</small>
    <div class="col-1"></div>
    <div class="col-2 mt-5">
      <i class="fa-solid fa-phone-volume"></i>
      <h6>Customer service</h6>
      <a href="#" class="link-hover gy-4 mb-5">+92 3942 7879</a>
      <br>
      <small>Call us from 8am to 8pm</small>
    </div>
    <div class="col-2 mt-5">
      <i class="fa-regular fa-message"></i>
      <h6>Chat with us</h6>
      <a href="#" class="link-hover gy-4 mb-5"><i class="fa-regular fa-circle text-success"></i>Live Chat</a>
      <br>
      <small>Call us from 8am to 8pm</small>
    </div>
    <div class="col-2 mt-5">
      <i class="fa-regular fa-envelope"></i>
      <h6>Write to us</h6>
      <a href="#" class="link-hover gy-4 mb-5">contact@example.com</a>
      <br>
    </div>
    <div class="col-2 icon-hover mt-5">
      <i class="fa-solid fa-user-plus"></i>
      <h6>Follow Us</h6>
      <a href="#"><i class="fa-brands fa-facebook-f me-2"></i></a>
      <a href="#"><i class="fa-brands fa-tiktok me-2"></i></a>
      <a href="#"><i class="fa-brands fa-x-twitter me-2"></i></a>
      <a href="#"><i class="fa-brands fa-youtube me-2"></i></a>
      <a href="#"><i class="fa-brands fa-instagram me-2"></i></a>
    </div>
    <div class="col-1"></div>
    <div class="row  pt-5 text-center">
      <h2>Do you have some questions?</h2>
      <div class="col-2"></div>

    <form action="save_message.php" method="POST" class="col-8 mt-5" id="contactForm">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
Message Sent Successfully!
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
        <p id="formError" class="text-danger fw-bold"></p>
        <div class="mb-3 d-flex justify-content-between">
          <div class="col-6  me-3">
            <input type="text" name="name" class="form-control bg-body-secondary p-3" id="userName"
            placeholder="Name OR Surname *"
required>
            <p class="text-danger"></p>
          </div>
          
        </div>
        <div class="mb-3">
         <input type="email" name="email"
             class="form-control bg-body-secondary p-3"
             id="userEmail" placeholder="Email *">
          <p class="text-danger"></p>
        </div>

<div class="mb-3">
<input type="text"
name="subject"
class="form-control bg-body-secondary p-3"
id="userSubject"
placeholder="Subject *">
</div>

        <div class="mb-3">
          <textarea
      name="message"
     class="form-control bg-body-secondary p-3"
     id="userMsg"
     placeholder="Message"
     rows="7"></textarea>
        </div>
        <div class="mb-5 red-button-hover">
          <button class="btn btn-dark w-100 P-3 fw-bold" type="submit">GET IN TOUCH</button>
        </div>
      </form>

     

    </div>
    <iframe
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d423286.8830297217!2d-118.74138205907403!3d34.02003919141475!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2c75ddc27da13%3A0xe22fdf6f254608f4!2sLos%20Angeles%2C%20CA%2C%20USA!5e0!3m2!1sen!2seg!4v1757530248798!5m2!1sen!2seg"
      width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
      referrerpolicy="no-referrer-when-downgrade"></iframe>

    <div class="row mt-5 pt-3 pb-3 brand-hover ">
      <h2 class="mb-5">Stores around the world</h2>
      <div class="card border-0 text-start ms-5" style="width: 24rem; padding-left: 100px;">
        <img src="images/about-2.jpg" class="card-img-top w-100">
        <div class="card-body">
          <h5 class="card-title">Los Angeles</h5>
          <small>34 Main Street, Los Angeles 9021 United States</small>
          <br>
          <small>+02 1234 567 88</small>
        </div>
      </div>
      <div class="card border-0 text-start" style="width: 24rem; padding-left: 100px;">
        <img src="images/about-3.jpg" class="card-img-top w-100">
        <div class="card-body">
          <h5 class="card-title">New York</h5>
          <small>515 Broadway 10015 New York United States</small>
          <br>
          <small>+49 1234 567 88</small>
        </div>
      </div>
      <div class="card border-0 text-start" style="width: 24rem; padding-left: 100px;">
        <img src="images/about-4.jpg" class="card-img-top w-100">
        <div class="card-body">
          <h5 class="card-title">California</h5>
          <small>1000 California St 68114 Omaha United States</small>
          <br>
          <small>+49 1234 567 88</small>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid bg-dark text-white linkwhite">
    <div class="row d-flex justify-content-between align-items-center  text-center mb-4">
      <div class="col-2 mb-5 gy-5">
        <a href="index.html"><img src="images/logowhite.png" class="w-50 pb-2"></a>
        <br>
        <i class="fa-solid fa-location-dot text-secondary"></i>
        <small class="pb-2 text-secondary">29 SE 2nd Ave, Miami Florida 33131, United States</small>
        <br>
        <i class="fa-solid fa-envelope text-secondary"></i>
        <small class="text-secondary">info@example.com</small>
        <a href="#">
          <h6 class="pt-3 ">(+92) 3942 7879</h6>
        </a>
      </div>
      <div class="col-2 gy-5 gx-0">
        <ul class="small">
          <li class="pb-3"><strong>SHOPPING</strong></li>
          <br>
          <li><a href="#">Whishlist</a></li>
          <br>
          <li><a href="#">Shop by brand</a></li>
          <br>
          <li><a href="#">Offers</a></li>
          <br>
          <li><a href="#">Track order</a></li>
          <br>
          <li><a href="#">Size Guide</a></li>
        </ul>
      </div>
      <div class="col-2 gy-5 gx-0">
        <ul class="small">
          <li class="pb-3"> <strong>INFORMATION</strong></li>
          <br>
          <li><a href="#">Track Order</a></li>
          <br>
          <li><a href="#">Shipping & Returns</a></li>
          <br>
          <li><a href="#">About us</a></li>
          <br>
          <li><a href="#">Help</a></li>
          <br>
          <li><a href="#">Gift Cards</a></li>
        </ul>
      </div>
      <div class="col-2 gy-5 gx-0 ">

        <ul class="small">
          <li class="pb-3"><strong>ACCOUNT</strong></li>
          <br>
          <li><a href="#">Cart</a></li>
          <br>
          <li><a href="#">My account</a></li>
          <br>
          <li><a href="#">My orders</a></li>
          <br>
          <li><a href="#">Wishlist</a></li>
          <br>
          <li><a href="#">Affiliate Program</a></li>
        </ul>
      </div>
      <div class="col-3 gx-0 ">
        <h5>Let’s keep in touch</h5>
        <div class="input-group mt-3 mb-3 w-75 mx-auto">
          <input type="email" class="form-control p-2 small" id="exampleFormControlInput1"
            placeholder="enter your email address">
          <button class="btn position-absolute end-0 me-2 " type="button" id="button-addon2"><i
              class="fa-solid fa-arrow-right"></i></button>
        </div>
        <div class="icon-hover mt-2">
          <a href="#"><i class="fa-brands fa-facebook-f me-2"></i></a>
          <a href="#"><i class="fa-brands fa-tiktok me-2"></i></a>
          <a href="#"><i class="fa-brands fa-x-twitter me-2"></i></a>
          <a href="#"><i class="fa-brands fa-youtube me-2"></i></a>
          <a href="#"><i class="fa-brands fa-instagram me-2"></i></a>
        </div>
      </div>
    </div>
    <div class="row border d-flex justify-content-between align-items-center pt-5 pb-5">
      <div class="col-4 d-flex" style="padding-left: 100px;">
        <i class="fa-solid fa-phone fs-1"></i>
        <div>
          <h6>Didn't find what you were looking for?</h6>
          <a href="#" class="link-hover gy-4 mb-5 text-center">Contact Us</a>
        </div>
      </div>
      <div class="col-4 d-flex"style="padding-left: 100px;">
        <i class="fa-regular fa-face-smile fs-1"></i>
        <div>
          <h6>How can we help you today?</h6>
          <a href="#" class="link-hover gy-4 mb-5 text-center">Help Center</a>
        </div>
      </div>
      <div class="col-4 d-flex"style="padding-left: 100px;">
        <i class="fa-solid fa-dharmachakra fs-1"></i>
        <div>
          <h6>We’d love to hear what you think!</h6>
          <a href="#" class="link-hover gy-4 mb-5 text-center">Give Feedback</a>
        </div>
      </div>


    </div>
    <footer class="d-flex justify-content-between align-items-center mt-5">
      <div class="col-4 mb-3"><small>Copyright © Merto. All Rights Reserved</small></div>
      <div class="col-4 mb-3">
        <img src="images/payment-icons-1white.png" class="w-100">
      </div>
      <a href="#navbar" id="upArrow"
        class="position-fixed bottom-0 end-0 mb-2 me-2 p-2 rounded-3 text-white border bg-dark fs-6"><i
          class="fa-solid fa-arrow-up"></i></a>
    </footer>

  </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
    crossorigin="anonymous"></script>
  <!--<script src="js/script.js"></script>-->
</body>

</html>